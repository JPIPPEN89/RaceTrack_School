//	Joshua Pippen

#include "Position_JP.h"

Position::Position() {
	col = 0;
	row = 0;
}

Position::Position(short c, short r) {
	col = c;
	row = r;
}