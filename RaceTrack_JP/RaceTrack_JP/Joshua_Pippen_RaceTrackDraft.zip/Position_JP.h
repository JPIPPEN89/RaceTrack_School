//  Joshua Pippen

#pragma once
#ifndef POSITION_JP_H
#define	POSITION_JP_H

#include <cstdlib>
#include <iostream>



class Position {
private:
	

public:

	short col;

	short row;

	Position();
		
	Position(short c, short r);
};




#endif
